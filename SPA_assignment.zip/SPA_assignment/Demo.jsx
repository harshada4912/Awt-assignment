import React from 'react'

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Contact from './Contact';
import About from './About';
import Login from './Login';
import Info from './Info';
import HomePage from './HomePage';
import Nav from './Nav';


const Demo = () => {
    return (
        <>
            <BrowserRouter>
                    <Nav />
                <Routes>
                    <Route path='/' element={<HomePage />} />
                    <Route path='/info' element={<Info />} />
                    <Route path='/login' element={<Login />} />
                    <Route path='/contact' element={<Contact />} />
                    <Route path='/about' element={<About />} />
                </Routes>
            </BrowserRouter>

        </>
    )
}

export default Demo;