import React from 'react'

const Contact = () => {
  return (
    <h1>This is Contact us page </h1>
  )
}

export default Contact;