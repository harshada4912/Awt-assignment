import React from 'react'

const HomePage = () => {
    return (
        <>
            <h1>This is HomePage </h1>

        </>
    )
}

export default HomePage;